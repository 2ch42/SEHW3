#include <string>

using namespace std;

class SignOutUI{
  public:
    void requestSignOut();
};

class SignOut{
  public:
    static string disconnectAccount();
};
