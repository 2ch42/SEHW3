#include <iostream>
#include <string>
#include "Account.h"


class DeleteAccountUI{
  public:
    void requestDelete();
};
class DeleteAccount{
  public:
    static void removeAccount();
};
